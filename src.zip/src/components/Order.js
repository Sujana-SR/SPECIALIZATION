import React from 'react'
import { NavLink } from 'react-router-dom'

const Order = () => {
return (
    <div class="text-center">
        <p>Your Order has been confirmed</p>
<h1 class="display-3">Thank You!</h1>


<p>
Having trouble? <NavLink to="/contact" href="">Contact us</NavLink>
</p>
<p class="lead">

<NavLink to="/home" className="btn btn-outline-dark mb-5 w-25 mx-auto">Continue To Homepage</NavLink>
</p>
</div>
)
}
export default Order