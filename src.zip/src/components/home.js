import React from 'react';
import './home.css';

//function Home()
//{
  //  return(
      //  <div>
    //        <h1>This is Home Component</h1>
        //</div>
   // );
//}

//export const Home = ()=>{
//        return( <div>
  //          <h1> this is the home componenet</h1>
    //        </div>);
    //};
//}



function Home(){
    return( <div>
        <h1> this is the function componenet</h1>
        <p>demo text</p>
        </div>);
};

export default Home;