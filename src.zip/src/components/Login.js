import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import Header from './Header';
import App from '../App';
  
class Login extends Component {

  static defaultProps = {
    flag:false
    }
    constructor(props) {
      
        super(props);
        this.state = {
          
          email:'',
          password:'',
          error:''
        }
        
    }
  

    handelChange=event=>{
      this.setState({[event.target.name]:event.target.value})
  }
  handelSubmit=event=>{

      
      event.preventDefault()
      console.log(this.state);
      axios.post('http://localhost:8087/signin',this.state). then(res=>{
          console.log(res.data);
          window.location.replace("/products");
         Login.defaultProps.flag=true
          
         
    
          

      }).catch(
          err=>{
              console.log("data already present")
              this.setState({error:'Invalid Username or password'})
              
          }
      )
    
  }
    render() { 
      const{email,password,error}=this.state
        return ( 
        
        <div>
          
          <section className="vh-100" Style="background-image: url('https://images8.alphacoders.com/404/thumb-1920-404735.jpg');">
  <div className="container py-5 h-100">
    <div className="row d-flex justify-content-center align-items-center h-100">
      <div className="col-12 col-md-8 col-lg-6 col-xl-5">
        <div className="card shadow-2-strong" Style="border-radius: 1rem;">
          <div className="card-body p-5 text-center">
  

          {error ? <h2>{error}</h2>:null} 
            
            <h3 className="mb-5">Sign in</h3>

            <form onSubmit={this.handelSubmit}>

            <div className="form-outline mb-4">
            <label  htmlfor="typeEmailX-2" className="form-label">Email</label>
              <input type="email" id="typeEmailX-2" className="form-control form-control-lg" name="email" value={email} aria-describedby="emailHelp" onChange={this.handelChange} />
              
            </div>

            <div className="form-outline mb-4">
            <label htmlfor="typePasswordX-2" className="form-label">Password</label>
              <input type="password" id="typePasswordX-2" className="form-control form-control-lg " name="password" value={password} onChange={this.handelChange}  />
            
            </div>

            
            <div className="form-check d-flex justify-content-start mb-4">
              <input
                className="form-check-input"
                type="checkbox"
                value=""
                id="form1Example3"
              />
              <label className="form-check-label" for="form1Example3"> Remember password </label>
            </div>

            <button className="btn btn-dark btn-lg btn-block" type="submit">Login</button>

            <p>Don't have account  <Link to='/register'> Register Here!!</Link></p>

            <hr className="my-4"></hr>

            <button className="btn btn-lg btn-block btn-primary" Style="background-color: #dd4b39;" type="submit"><i className="fab fa-google me-2"></i>Sign in with google</button>
            <button className="btn btn-lg btn-block btn-primary mb-2" Style="background-color: #3b5998;" type="submit" ><i className="fab fa-facebook-f me-2"></i>Sign in with facebook</button>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
      
        </div> );
    }
}
 
export default Login;