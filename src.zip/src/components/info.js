import {Component} from 'react';
import './info.css';

class info extends Component{

    constructor()
    {
        super();
        this.state= {
            greet:"welcome sujana"
        }
    }

    changeGreet()
    {
        this.setState({
            greet: "welcome sin",
            name:"raj kumar"
        });
    }
    render()
    {
        return(
            <div>
             {/*   <h1>this is class Component {this.props.name}</h1> */}

             <h1> {this.state.greet} </h1>
             <button onClick={()=>{ this.changeGreet()}}> greet</button>
            </div>
        );
    }
}
export default info;