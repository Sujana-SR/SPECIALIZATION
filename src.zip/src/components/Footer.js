import React from 'react'

const Footer = () => {
    return (
        <div>

            <footer class="background">

                <p class="text-footer">
                    Copyright ©-All rights are reserved
                </p>

                 </footer>

                </div>



               
        
    )
}

export default Footer
