
import { Component } from 'react/cjs/react.production.min';
import './App.css';
import Home from './components/home';

import Info from './components/info'
import About from './components/about';
//functional component
function App() {
  return (
    <div>
    <div>
            
            {/* <Home/> */}
            {/*<Info name="sujana"/> */}
           {/*} <About name="sujana" age="18"/> <h2> just for demo</h2>
            <About name="nia" age="18"/>
          <About name="ria" age="19"/> */}
<Info></Info>
<About/>

      </div>
      </div>
  );
}



export default App;
