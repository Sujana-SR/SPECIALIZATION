import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footter',
  templateUrl: './footter.component.html',
  styleUrls: ['./footter.component.css']
})
export class FootterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
