import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
msg:string="";

  prop: string='';
  demo:any=[
    {'email':'rahul@gmail.com','password':12345678},
    {'email':'riza@gmail.com','password':1234567},
    {'email':'niya@gmail.com','password':123456},
    {'email':'raj@gmail.com','password':123456},
    
  ]
 
  constructor() { }

  ngOnInit(): void {
  }
login(value:any){
if(value.email == this.demo.email  && value.password == this.demo.password)  
{
   this.msg='successfully logged in';
   this.prop='green';
   
}
else{
  this.msg='login not successful';
  this.prop='red';
  
}
}
}
