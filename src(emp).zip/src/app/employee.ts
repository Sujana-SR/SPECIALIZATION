export class Employee{

    id:number=0;
    name:String='';
    city:String='';
}