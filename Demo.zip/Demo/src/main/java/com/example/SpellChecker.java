package com.example;
public class SpellChecker {

        public SpellChecker(){
            System.out.println("We are Inside SpellChecker constructor." );
        }
        public void checkSpelling(){
            System.out.println("We are Inside checkSpelling." );
        }

}
