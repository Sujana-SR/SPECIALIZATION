package com.example;
import com.autowire.beans.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class MainApp {
        public static void main(String[] args) {



            ApplicationContext context = new ClassPathXmlApplicationContext("Bean2.xml");



            TextEditor textEditor = (TextEditor) context.getBean ("texteditor");



            System.out.println(textEditor.spellCheck());



            System.out.println(textEditor.getSpellChecker());
        }
    }

