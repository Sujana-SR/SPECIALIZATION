package BeanInheritance;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

        public static void main(String a[]){

            ConfigurableApplicationContext context
                    = new ClassPathXmlApplicationContext("Book.xml");   //replace Book.xml with abstract.xml
                    Book mybook = (Book) context.getBean("myBookBean");
            System.out.println(mybook.toString());
        }
    }

