package BeanPostProcessor;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import BeanPostProcessor.TestConnection;


public class TestMain {

        public static void main(String[] args) {
            ConfigurableApplicationContext context  = new ClassPathXmlApplicationContext("Postprocessor.xml");
            TestConnection networkMng = (TestConnection) context.getBean("connectionmanager");
            networkMng.readData();
            context.close();
        }}

