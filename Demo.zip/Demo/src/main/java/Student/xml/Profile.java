package Student.xml;public class Profile {
}
