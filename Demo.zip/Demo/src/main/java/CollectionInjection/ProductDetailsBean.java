package CollectionInjection;

public class ProductDetailsBean {
}
