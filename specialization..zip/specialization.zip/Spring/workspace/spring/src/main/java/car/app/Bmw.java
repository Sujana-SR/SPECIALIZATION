package car.app;


import org.springframework.stereotype.Component;

@Component
public class Bmw extends Car {
	
	public void demo() {
		System.out.println("bmw cars");
	}

}
