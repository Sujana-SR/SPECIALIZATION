package com.springexamples.spring;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan("com.springexamples.spring")
public class StudentConfig {
}



