package car.app;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Component;

@Component
public class Manufacture {

	@Autowired
	Car car;
	
	public void buildCar() {
		car.demo();
	}
}
