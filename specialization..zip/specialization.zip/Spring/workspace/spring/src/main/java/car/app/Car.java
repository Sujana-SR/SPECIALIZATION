package car.app;

public class Car {
public void demo() {
}

public void geMusic() {
	System.out.println("music system added");
}
}
