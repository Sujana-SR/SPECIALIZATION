package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springexamples.spring.Student;
import com.springexamples.spring.StudentConfig;


public class App
{
public static void main( String[] args )
{
ApplicationContext context=new AnnotationConfigApplicationContext(StudentConfig.class);
Student stu=(Student)context.getBean("student");
stu.details();
}
}

